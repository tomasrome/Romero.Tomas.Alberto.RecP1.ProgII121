package recpp;

import java.time.LocalDate;
import model.AtaqueDuplicadoException;
import model.MisilBalistico;
import model.MisilCrucero;
import model.SimuladorDeConflicto;

public class RecPP {

    public static void main(String[] args) {

        try {

            SimuladorDeConflicto simulador = new SimuladorDeConflicto();

            MisilBalistico mb1 = new MisilBalistico("Argentina", LocalDate.of(2025, 6, 19), 1500, "Uruguay", true);

            MisilBalistico mb2 = new MisilBalistico("Brasil", LocalDate.of(2025, 6, 10), 1000, "Paraguay", false);

            MisilCrucero mc1 = new MisilCrucero("Chile", LocalDate.of(2025, 6, 4), 10000, "peru", 5);

            simulador.lanzarMisil(mb1);
            simulador.lanzarMisil(mb2);
            simulador.lanzarMisil(mc1);

            simulador.mostrarTodosLosMisiles();

            
            System.out.println("\nInterceptando misiles: ");
            simulador.interceptarMisiles();

        } catch (AtaqueDuplicadoException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
