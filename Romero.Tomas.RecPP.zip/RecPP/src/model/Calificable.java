
package model;


public interface Calificable {
    
    void calificarAmenaza(int puntaje);
}
