
package model;

import java.util.ArrayList;
import java.util.List;


public class SimuladorDeConflicto {
    
    private List<Misil> misiles = new ArrayList<>();
    
    
    public void lanzarMisil(Misil m){
        validarMisilDuplicado(m);
        if(m != null){
            misiles.add(m);
            System.out.println("Misil lanzado");
        }
    }
    
    
    private void validarMisilDuplicado(Misil misil){
        for (Misil m : misiles){
            if(m.equals(misil)){
                throw new AtaqueDuplicadoException();
            }
        }
    }
    
    
    public void mostrarTodosLosMisiles(){
        System.out.println("\nMisiles Registrados: ");
        for (Misil m : misiles){
            System.out.println(m);
        }
    }
    
    
    public void interceptarMisiles(){
        for (Misil m : misiles){
            if (m instanceof Interceptable){
                ((Interceptable) m).puedeSerInterceptado();
            }else{
                System.out.println("El Misil Balistico no se ha podido interceptar.");
            }
        }
    }
    
    
    
    public void calificarAtaque(String pais, int puntaje){
        
    }
    
}
