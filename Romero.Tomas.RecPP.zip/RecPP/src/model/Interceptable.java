
package model;


public interface Interceptable {
    
    void puedeSerInterceptado();
}
