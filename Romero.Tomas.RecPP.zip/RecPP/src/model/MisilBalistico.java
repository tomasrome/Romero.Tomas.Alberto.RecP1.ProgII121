package model;

import java.time.LocalDate;

public class MisilBalistico extends Misil implements Calificable {

    private boolean cargaNuclear;
    private NivelAmenaza nivelAmenaza;

    public MisilBalistico(String paisLanzador, LocalDate fechaLanzamiento, double alcance, String objetivo, boolean cargaNuclear) {
        super(paisLanzador, fechaLanzamiento, alcance, objetivo);
        this.cargaNuclear = cargaNuclear;
    }
    
    
    public NivelAmenaza getNivelAmenaza(){
        return nivelAmenaza;
    }
    
    @Override
    public void calificarAmenaza(int puntaje){
   
    }
    
    
    @Override
    public String toString(){
        return super.toString() + " | Con carga Nuclear: " + cargaNuclear;
    }
}
