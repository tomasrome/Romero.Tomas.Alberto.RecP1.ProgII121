
package model;

import java.time.LocalDate;


public class MisilCrucero extends Misil implements Calificable, Interceptable {
    
    private double velocidad;
    
    public MisilCrucero(String paisLanzador, LocalDate fechaLanzamiento, double alcance, String objetivo, double velocidad){
        super(paisLanzador, fechaLanzamiento, alcance, objetivo);
        this.velocidad = velocidad;
    }
    
    @Override
    public void calificarAmenaza(int puntaje) {
        
    }
    
    
    @Override
    public void puedeSerInterceptado(){
        System.out.println("Misil Crucero interceptado exitosamente.");
    }
}
