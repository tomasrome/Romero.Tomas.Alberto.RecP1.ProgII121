
package model;


public class AtaqueDuplicadoException extends RuntimeException{
    
    private static final String MENSAJE = "Ya existe un misil con el mismo pais lanzador, misma fecha de lanzamiento y mismo objetivo";
    
    public AtaqueDuplicadoException(){
        this(MENSAJE);
    }
    
    public AtaqueDuplicadoException(String mensaje){
        super(mensaje);
    }
    
}

