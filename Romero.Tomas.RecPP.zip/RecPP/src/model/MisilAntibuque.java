
package model;

import java.time.LocalDate;


public class MisilAntibuque extends Misil implements Interceptable {
    
    private boolean preciso;
    
    
    public MisilAntibuque(String paisLanzador, LocalDate fechaLanzamiento, double alcance, String objetivo, boolean preciso){
        super(paisLanzador, fechaLanzamiento, alcance, objetivo);
        this.preciso = preciso;
    }
    
    
    @Override
    public void puedeSerInterceptado(){
        System.out.println("Misil Antibuque interceptado exitosamente.");
    }
    
    
}
