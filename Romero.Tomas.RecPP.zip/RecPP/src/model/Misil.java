
package model;

import java.time.LocalDate;
import java.util.Objects;


public abstract class Misil {
    
    private String paisLanzador;
    private LocalDate fechaLanzamiento;
    private double alcance;
    private String objetivo;
    
    
    public Misil(String paisLanzador, LocalDate fechaLanzamiento, double alcance, String objetivo){
        this.paisLanzador = paisLanzador;
        this.fechaLanzamiento = fechaLanzamiento;
        this.alcance = alcance;
        this.objetivo = objetivo;
    }
    
    
    
    
    @Override
    public boolean equals(Object o){
        if (o == null || !(o instanceof Misil m)){
        return false;
    }
        return this.paisLanzador.equals(m.paisLanzador) && this.fechaLanzamiento.equals(m.fechaLanzamiento) && this.objetivo.equals(m.objetivo);   
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(paisLanzador, fechaLanzamiento, objetivo);
    }
    
    
    @Override
    public String toString(){
        return "Pais lanzador: " + paisLanzador + " | Fecha de lanzamiento: " + fechaLanzamiento + " | Alcance: " + alcance + " | Objetivo: " + objetivo;
    }
   
 
  
}
