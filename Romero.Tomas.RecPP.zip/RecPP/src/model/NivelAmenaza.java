
package model;


public enum NivelAmenaza {
    BAJA,
    MEDIA,
    ALTA
}
